#!/bin/bash

cd /var/www/html/sofieapi/scripts/
php sendStatusData.php
