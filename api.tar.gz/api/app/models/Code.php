<?php

class Code extends \Eloquent {

	protected $table = 't_code';
	public $timestamps = false;
		
	protected $primaryKey = 'IDCode';
	
}