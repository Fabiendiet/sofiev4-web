<?php

class UserGroup extends Eloquent {

	protected $table = 'users_groupes';
	public $timestamps = false;
		
	protected $guarded = array();

}
