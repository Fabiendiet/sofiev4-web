<?php

class GroupeDroit extends Eloquent {

	protected $table = 'groupes_droits';
	public $timestamps = false;
		
	protected $guarded = array();

}
