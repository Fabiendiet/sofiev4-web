<?php

class TypePanne extends Eloquent {

	protected $table = 't_type_panne';
	public $timestamps = false;
		
	protected $primaryKey = 'id';
	protected $guarded = array();

}
