
			<div class="box-content">
				<div id="graph_globale" style="height:450px;font-family: Verdana, Arial, Helvetica, sans-serif;font-size: 12px;border-width: 2px;border-style: solid;		    
																	margin: 0;
																	margin-top: 3px;">
				
				</div>
			</div>
		